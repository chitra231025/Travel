<?php
// Set database connection parameters
$servername = "localhost";   // Usually localhost in XAMPP
$username = "root";          // Default username in XAMPP is "root"
$password = "";              // Default password is empty
$dbname = "personal_info_db"; // The database you created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data from the POST request
$name = $_POST['name'];
$phone = $_POST['phone'];
$city = $_POST['city'];
$district = $_POST['district'];
$father_name = $_POST['father_name'];
$mother_name = $_POST['mother_name'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$pincode = $_POST['pincode'];

// Prepare the SQL query
$sql = "INSERT INTO personal_info (name, phone, city, district, father_name, mother_name, email, dob, pincode) 
        VALUES ('$name', '$phone', '$city', '$district', '$father_name', '$mother_name', '$email', '$dob', '$pincode')";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
